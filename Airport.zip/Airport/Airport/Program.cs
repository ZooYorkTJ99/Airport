﻿using System;

namespace Airport
{ 
    class Program
    {
        /*
         * [Sample Data and Program entry]
         * 
         * User will enter Exit to end the program
         * User will enter Load Queue to load the current flight schedule
         * User will enter "small" or "large" to retreive the next flight
         * When 0 planes(null) is returned message will display no valid Planes available.
         * 
         */

        static void Main(string[] args)
        {
            AirportQueue queue = new AirportQueue();
            bool _stopApp = false;
            string queueData = "[{ \"id\":\"23\",\"size\":\"small\",\"type\":\"cargo\"}," +
                                "{ \"id\":\"10\",\"size\":\"large\",\"type\":\"passenger\"}," +
                                "{ \"id\":\"15\",\"size\":\"large\",\"type\":\"passenger\"}," +
                                "{ \"id\":\"140\",\"size\":\"large\",\"type\":\"cargo\"}," +
                                "{ \"id\":\"102\",\"size\":\"small\",\"type\":\"cargo\"}," +
                                "{ \"id\":\"95\",\"size\":\"small\",\"type\":\"passenger\"}," +
                                "{ \"id\":\"19\",\"size\":\"large\",\"type\":\"passenger\"}," +
                                "{ \"id\":\"47\",\"size\":\"small\",\"type\":\"cargo\"}," +
                                "{ \"id\":\"32\",\"size\":\"large\",\"type\":\"cargo\"}," +
                                "{ \"id\":\"9\",\"size\":\"small\",\"type\":\"passenger\"}]";

            while (!_stopApp)
            {
                string input = Console.ReadLine();

                if (input.ToUpper().Equals("EXIT"))
                {
                    _stopApp = true;
                }
                else if(input.ToUpper().Equals("LOAD QUEUE"))
                {
                    queue.LoadQueue(queueData);
                    Console.WriteLine("*QueueLoaded*");
                }
                else if(input.ToUpper().Equals("SMALL") || input.ToUpper().Equals("LARGE"))
                {
                    Plane newPlane = queue.NextPlane(input);
                    if(newPlane != null)
                    {
                        Console.WriteLine("Plane " + newPlane.id + " took off");
                    }
                    else
                    {
                        Console.WriteLine("No valid planes available for the entry provided...");
                    }
                }
                else
                {
                    Console.WriteLine("Entry not valid...");
                }
            }
        }
    }
}
